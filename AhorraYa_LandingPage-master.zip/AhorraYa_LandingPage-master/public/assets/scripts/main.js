document.addEventListener('DOMContentLoaded', () => {
    console.log("JavaScript cargado correctamente.");
});
